# Cisco Packet Tracer Labs

Hands on Cisco Packet Tracer labs demonstrating networking fundamentals, IP addressing, subnetting, network services, wireless connectivity, and basic troubleshooting.

## Labs

### 1. DNS, DHCP, and Web Services

A small local network using DHCP for client addressing, DNS for name resolution, and HTTP servers for simulated web services.

### 2. Office Network Subnetting

An office network divided into separate Accounts and Delivery subnets and connected through a router.

### 3. IoT Network and Server

A mixed wired and wireless network connecting smart devices, an access point, a switch, a server, and a workstation.
